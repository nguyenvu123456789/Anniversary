import { createRouter, createWebHistory } from 'vue-router'
import App from '../App.vue'
import Gift1View from '../views/Gift1View.vue'

const router = createRouter({
    history: createWebHistory(),

    routes: [
        {
            path: '/',
            name: 'home',
            component: App,
        },
        {
            path: '/gift/1',
            name: 'gift-1',
            component: Gift1View,
        },
    ],

    scrollBehavior(to, from, savedPosition) {
        if (savedPosition) {
            return savedPosition
        }

        return {
            top: 0,
            behavior: 'smooth',
        }
    },
})

export default router